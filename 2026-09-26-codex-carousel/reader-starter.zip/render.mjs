import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import puppeteer from 'puppeteer';

const root = dirname(fileURLToPath(import.meta.url));
const [spec, style] = await Promise.all(
  ['spec.json', 'style.json'].map(async name => JSON.parse(await readFile(join(root, name), 'utf8'))),
);
if (!Array.isArray(spec) || spec.length !== 6 || !Array.isArray(style.cards) || style.cards.length !== 6) {
  throw new Error('spec.json과 style.json에는 카드 6장이 필요합니다.');
}
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const prose = value => escapeHtml(value).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
const body = (card, kind) => {
  if (kind === 'compare') return `<div class="columns">${['a','b'].map(key => `<div class="box"><h2>${prose(card[key]?.h)}</h2><p>${prose(card[key]?.v)}</p><small>${prose(card[key]?.d)}</small></div>`).join('')}</div>`;
  if (kind === 'code') return `<div class="list">${(card.lines ?? []).map(line => `<div>${prose(line.t)}</div>`).join('')}</div><p class="note">${prose(card.note)}</p>`;
  if (kind === 'steps') return `<div class="list">${(card.rows ?? []).map(row => `<div><b>${prose(row.no)}. ${prose(row.t)}</b><span>${prose(row.d)}</span></div>`).join('')}</div>`;
  if (kind === 'quote') return `<blockquote>${prose(card.q)}</blockquote><p class="note">${prose(card.by)}</p>`;
  if (kind === 'cta') return `<div class="cta">${prose(card.btn)}</div><p class="note">${prose(card.credit)}</p>`;
  return `<p class="subtitle">${prose(card.sub)}</p>`;
};
const html = (card, theme) => `<!doctype html><html lang="ko"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}html,body{margin:0;width:1080px;height:1350px;overflow:hidden}
body{font-family:Arial,"Apple SD Gothic Neo","Noto Sans CJK KR",sans-serif;background:${theme.paper === 'cream' ? '#fff6e7' : '#121f30'};color:${theme.paper === 'cream' ? '#162333' : '#fff8e9'}}
main{position:relative;width:1080px;height:1350px;padding:88px 80px;display:flex;flex-direction:column}
header{font-size:27px;font-weight:800;letter-spacing:.06em;color:#e6aa68;margin-bottom:90px}
h1{font-size:72px;line-height:1.21;letter-spacing:-.035em;margin:0 0 52px;white-space:normal;word-break:keep-all}
strong{color:#ffb96c}.subtitle{font-size:43px;line-height:1.5;margin-top:55px}
.columns{display:flex;gap:22px;margin-top:20px}.box{flex:1;min-height:485px;border:3px solid #e7ad67;border-radius:24px;padding:32px;background:#ffffff13}
.box h2{font-size:37px}.box p{font-size:43px;line-height:1.45;word-break:keep-all}.box small{font-size:28px;line-height:1.4}
.list{display:grid;gap:21px;margin-top:15px}.list>div{padding:23px 30px;border-radius:20px;border:2px solid #e6aa68;background:#ffffff16;font-size:38px;line-height:1.45;word-break:keep-all}.list span{display:block;font-size:28px;opacity:.8}
blockquote{margin:50px 0 0;padding:45px;border-left:12px solid #e6aa68;background:#ffffff16;border-radius:15px;font-size:49px;line-height:1.55;word-break:keep-all}
.cta{margin-top:90px;border-radius:24px;background:#e6aa68;color:#162333;padding:38px;font-size:39px;font-weight:800;text-align:center}
.note{font-size:30px;line-height:1.5;margin-top:42px}footer{margin-top:auto;font-size:27px;border-top:2px solid #e6aa68;padding-top:25px;color:#e6aa68}
</style></head><body><main><header>CODEX × 카드뉴스 실습</header><h1>${prose(card.title || (theme.kind === 'quote' ? '바로 쓸 수 있는 답장' : '내 주제로 바꿔 쓰기'))}</h1>${body(card, theme.kind)}<footer>${prose(card.tag || '내 주제로 다시 만들기')}</footer></main></body></html>`;
const output = join(root, 'png');
const cards = join(root, 'cards');
await Promise.all([mkdir(output, {recursive:true}), mkdir(cards, {recursive:true})]);
const browser = await puppeteer.launch({headless:true});
try {
  const page = await browser.newPage();
  await page.setViewport({width:1080,height:1350,deviceScaleFactor:1});
  for (let index = 0; index < 6; index++) {
    const card = spec[index];
    if (!/^[0-9]{2}-[a-z0-9-]+$/.test(card.out)) throw new Error(`카드 ${index+1}의 out 이름을 확인하세요.`);
    const markup = html(card, style.cards[index]);
    await writeFile(join(cards, `${card.out}.html`), markup);
    await page.setContent(markup, {waitUntil:'load'});
    await page.evaluate(() => document.fonts.ready);
    await page.screenshot({path:join(output, `${card.out}.png`),clip:{x:0,y:0,width:1080,height:1350}});
    console.log(`${card.out}.png 1080×1350`);
  }
  await page.close();
} finally {
  await browser.close();
}
