# 카드뉴스 PNG 실습 파일

이 폴더에는 예시 카드 문구 `spec.json`, 레이아웃 선택 `style.json`, 실행 파일 `render.mjs`, 의존성 `package.json`이 있습니다. 영상의 시연 카드는 해봄의 기존 렌더러로 제작했으며, 이 실습 파일은 같은 예시 문구를 독자의 컴퓨터에서 **별도의 간단한 디자인**으로 출력합니다.

1. [Node.js](https://nodejs.org/)를 설치합니다.
2. 이 폴더에서 `npm install`을 실행합니다. Puppeteer 설치가 브라우저를 내려받습니다. 설치가 막히면 `npx puppeteer browsers install`을 실행합니다.
3. `node render.mjs`를 실행합니다.
4. `png/`에 1080×1350 PNG 여섯 장이 생기는지 확인합니다. `cards/`에는 생성된 HTML이 남습니다.
5. `spec.json`의 문구나 `style.json`의 `paper`/`kind` 값을 고치고 같은 명령을 다시 실행합니다. `render.mjs`는 매번 JSON을 읽어 HTML과 PNG를 다시 만듭니다.

한 장만 고칠 때는 해당 `spec.json` 항목만 바꾸세요. 출력은 여섯 장을 다시 쓰지만 다른 항목의 **PNG 내용은 동일**합니다. 글자가 잘리면 문구를 줄이거나 `render.mjs`의 CSS 글꼴 크기를 조정하세요. 이 예시는 예약 실행이나 SNS 업로드를 하지 않습니다.
